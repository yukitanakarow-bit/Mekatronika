import tkinter as tk
from tkinter import ttk, messagebox
import serial
import serial.tools.list_ports
import threading
import json
import time

class ESP32TesterGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("ESP32 Hardware Tester")
        self.root.geometry("600x650")
        
        # --- Apply Dark Theme & Styling ---
        self.root.configure(bg="#2b2d42")
        
        style = ttk.Style()
        style.theme_use('clam')
        
        # Configure common colors
        bg_color = "#2b2d42"
        fg_color = "#edf2f4"
        btn_bg = "#8d99ae"
        btn_active = "#ef233c"
        
        style.configure('TFrame', background=bg_color)
        style.configure('TLabelframe', background=bg_color, foreground=fg_color, font=("Helvetica", 11, "bold"))
        style.configure('TLabelframe.Label', background=bg_color, foreground=fg_color)
        style.configure('TLabel', background=bg_color, foreground=fg_color)
        
        style.configure('TButton', background=btn_bg, foreground="#ffffff", font=("Helvetica", 10, "bold"), padding=5)
        style.map('TButton', background=[('active', btn_active)])
        
        style.configure('TScale', background=bg_color)
        
        # Apply to Text widget later
        self.text_bg = "#1f202f"
        self.text_fg = "#a2d2ff"
        # ----------------------------------
        
        self.serial_port = None
        self.is_connected = False
        
        self.create_widgets()
        self.refresh_ports()

    def create_widgets(self):
        # 1. Connection Frame
        conn_frame = ttk.LabelFrame(self.root, text="Connection", padding=10)
        conn_frame.pack(fill="x", padx=10, pady=5)
        
        ttk.Label(conn_frame, text="COM Port:").pack(side="left")
        self.port_var = tk.StringVar()
        self.port_combo = ttk.Combobox(conn_frame, textvariable=self.port_var, state="readonly", width=15)
        self.port_combo.pack(side="left", padx=5)
        
        ttk.Button(conn_frame, text="Refresh", command=self.refresh_ports).pack(side="left", padx=5)
        
        self.btn_connect = ttk.Button(conn_frame, text="Connect", command=self.toggle_connection)
        self.btn_connect.pack(side="left", padx=5)

        self.lbl_status = ttk.Label(conn_frame, text="Disconnected", foreground="#ef233c", font=("Helvetica", 10, "bold"))
        self.lbl_status.pack(side="right", padx=10)

        # 2. Sensor Data Frame
        sensor_frame = ttk.LabelFrame(self.root, text="Sensor Data", padding=10)
        sensor_frame.pack(fill="x", padx=10, pady=5)

        # Ultrasonic
        self.lbl_us = ttk.Label(sensor_frame, text="Ultrasonic: -- cm", font=("Helvetica", 12, "bold"))
        self.lbl_us.grid(row=0, column=0, sticky="w", pady=5)

        # Buttons
        self.lbl_btns = ttk.Label(sensor_frame, text="Buttons: [B1: 0, B2: 0, B3: 0]", font=("Helvetica", 12))
        self.lbl_btns.grid(row=1, column=0, sticky="w", pady=5)

        # MUX Frame
        mux_frame = ttk.Frame(sensor_frame)
        mux_frame.grid(row=2, column=0, sticky="w", pady=10)
        ttk.Label(mux_frame, text="MUX Sensors (0-4095):", font=("Helvetica", 10, "bold")).pack(anchor="w")
        
        self.mux_labels = []
        for i in range(8):
            lbl = ttk.Label(mux_frame, text=f"S{i}: ----", width=10)
            lbl.pack(side="left", padx=2)
            self.mux_labels.append(lbl)

        # 3. Motor Test Frame
        motor_frame = ttk.LabelFrame(self.root, text="Motor Test", padding=10)
        motor_frame.pack(fill="x", padx=10, pady=5)

        ttk.Label(motor_frame, text="Motor A (Left)").grid(row=0, column=0, padx=10)
        ttk.Label(motor_frame, text="Motor B (Right)").grid(row=0, column=2, padx=10)

        self.slider_A = ttk.Scale(motor_frame, from_=-255, to=255, orient="horizontal", length=200, command=self.on_slider_a_change)
        self.slider_A.grid(row=1, column=0, padx=10, pady=10)
        
        self.slider_B = ttk.Scale(motor_frame, from_=-255, to=255, orient="horizontal", length=200, command=self.on_slider_b_change)
        self.slider_B.grid(row=1, column=2, padx=10, pady=10)

        self.lbl_pwm_A = ttk.Label(motor_frame, text="PWM: 0", font=("Helvetica", 10, "bold"))
        self.lbl_pwm_A.grid(row=2, column=0)
        
        self.lbl_pwm_B = ttk.Label(motor_frame, text="PWM: 0", font=("Helvetica", 10, "bold"))
        self.lbl_pwm_B.grid(row=2, column=2)

        ttk.Button(motor_frame, text="Apply Speed", command=self.send_motor_cmd).grid(row=3, column=0, columnspan=3, pady=10)
        ttk.Button(motor_frame, text="STOP ALL", command=self.stop_motors).grid(row=4, column=0, columnspan=3)

        # 4. Command Log Frame
        log_frame = ttk.LabelFrame(self.root, text="Command Log", padding=10)
        log_frame.pack(fill="both", expand=True, padx=10, pady=5)
        
        # Add scrollbar to text widget
        scrollbar = ttk.Scrollbar(log_frame)
        scrollbar.pack(side="right", fill="y")
        self.txt_log = tk.Text(log_frame, height=6, state='disabled', yscrollcommand=scrollbar.set, bg=self.text_bg, fg=self.text_fg, font=("Consolas", 10))
        self.txt_log.pack(fill="both", expand=True)
        scrollbar.config(command=self.txt_log.yview)

    def on_slider_a_change(self, v):
        self.lbl_pwm_A.config(text=f"PWM: {int(float(v))}")
        self.send_motor_cmd()

    def on_slider_b_change(self, v):
        self.lbl_pwm_B.config(text=f"PWM: {int(float(v))}")
        self.send_motor_cmd()

    def refresh_ports(self):
        ports = [port.device for port in serial.tools.list_ports.comports()]
        self.port_combo['values'] = ports
        if ports:
            self.port_combo.current(0)

    def toggle_connection(self):
        if not self.is_connected:
            port = self.port_var.get()
            if not port:
                messagebox.showerror("Error", "Please select a COM port")
                return
            try:
                self.serial_port = serial.Serial(port, 115200, timeout=1)
                self.is_connected = True
                self.btn_connect.config(text="Disconnect")
                self.lbl_status.config(text="Connected", foreground="#a6e3a1")
                
                # Start reading thread
                self.read_thread = threading.Thread(target=self.read_serial, daemon=True)
                self.read_thread.start()
            except Exception as e:
                messagebox.showerror("Connection Error", str(e))
        else:
            self.is_connected = False
            if self.serial_port:
                self.serial_port.close()
            self.btn_connect.config(text="Connect")
            self.lbl_status.config(text="Disconnected", foreground="#ef233c")

    def read_serial(self):
        while self.is_connected:
            try:
                if self.serial_port.in_waiting > 0:
                    line = self.serial_port.readline().decode('utf-8').strip()
                    if line.startswith("{"):
                        try:
                            data = json.loads(line)
                            # Use after() to update UI from main thread
                            self.root.after(0, self.update_ui, data)
                        except json.JSONDecodeError:
                            pass # Ignore malformed json
            except Exception as e:
                print("Read error:", e)
                break
            time.sleep(0.01)

    def update_ui(self, data):
        if "us" in data:
            self.lbl_us.config(text=f"Ultrasonic: {data['us']} cm")
        if "btn" in data:
            btns = data["btn"]
            self.lbl_btns.config(text=f"Buttons: [B1: {btns[0]}, B2: {btns[1]}, B3: {btns[2]}]")
        if "mux" in data:
            mux = data["mux"]
            for i in range(8):
                if i < len(mux):
                    self.mux_labels[i].config(text=f"S{i}: {mux[i]}")

    def send_motor_cmd(self):
        if self.is_connected and self.serial_port:
            speedA = int(self.slider_A.get())
            speedB = int(self.slider_B.get())
            cmd = f"M:A:{speedA}:B:{speedB}\n"
            try:
                self.serial_port.write(cmd.encode('utf-8'))
                self.log_message(f"Sent motor cmd -> M:A: {speedA} | M:B: {speedB}")
            except Exception as e:
                self.log_message(f"Write error: {e}")
        else:
            self.log_message("Error: Not connected to ESP32")

    def stop_motors(self):
        self.slider_A.set(0)
        self.slider_B.set(0)
        self.lbl_pwm_A.config(text="PWM: 0")
        self.lbl_pwm_B.config(text="PWM: 0")
        self.send_motor_cmd()

    def log_message(self, msg):
        self.txt_log.config(state='normal')
        self.txt_log.insert(tk.END, f"[{time.strftime('%H:%M:%S')}] {msg}\n")
        self.txt_log.see(tk.END)
        self.txt_log.config(state='disabled')

if __name__ == "__main__":
    root = tk.Tk()
    app = ESP32TesterGUI(root)
    root.mainloop()
