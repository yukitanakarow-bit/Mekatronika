#ifndef HARDWARE_DEFS_H
#define HARDWARE_DEFS_H

#include <Arduino.h>

// ---------------------------------------------------------
// 1. I2C LCD (16x2 or 20x4)
// ---------------------------------------------------------
#define I2C_SDA_PIN 21
#define I2C_SCL_PIN 22

// ---------------------------------------------------------
// 2. Ultrasonic Sensor (HC-SR04)
// ---------------------------------------------------------
#define US_TRIG_PIN 19
#define US_ECHO_PIN 23

// ---------------------------------------------------------
// 3. MUX 8-Channel (74HC4051) for 8 Line Sensors
// ---------------------------------------------------------
#define MUX_S0_PIN 18
#define MUX_S1_PIN 17
#define MUX_S2_PIN 16
#define MUX_OUT_PIN 4

// ---------------------------------------------------------
// 4. L298N Motor Driver
// ---------------------------------------------------------
// Motor A (Left)
#define MOTOR_A_EN 32
#define MOTOR_A_IN1 33
#define MOTOR_A_IN2 25

// Motor B (Right)
#define MOTOR_B_EN 14
#define MOTOR_B_IN3 26
#define MOTOR_B_IN4 27

// PWM Settings for ESP32
#define PWM_FREQ 5000
#define PWM_RES 8
#define PWM_CH_A 0
#define PWM_CH_B 1

// ---------------------------------------------------------
// 5. Pushbuttons
// NOTE: PB2 and PB3 are on D34, D35 which are input-only
// and lack internal pull-ups. Requires external resistors!
// ---------------------------------------------------------
#define BTN_1_PIN 34
#define BTN_2_PIN 35
#define BTN_3_PIN 13

#endif // HARDWARE_DEFS_H
