#include <Arduino.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include "HardwareDefs.h"
#include "HardwareTest.h"
#include "LineFollower.h"

// Initialize LCD. 
// Assuming address 0x27 and 16x2 screen. Change to 0x3F if 0x27 doesn't work.
LiquidCrystal_I2C lcd(0x27, 16, 2);

void setup() {
    Serial.begin(115200);
    delay(100);

    // Initialize I2C for LCD with custom pins
    Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN);
    
    // Initialize LCD
    lcd.init();
    lcd.backlight();
    lcd.setCursor(0, 0);
    lcd.print("System Booting..");

    // Initialize all hardware pins
    setupHardware();

    // Tampilkan menu pilihan mode di LCD
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("B1:LF B2:Test");
    lcd.setCursor(0, 1);
    lcd.print("B3:Kalibrasi");
    
    int mode = 0;
    // Tunggu sampai salah satu tombol ditekan
    while (true) {
        if (digitalRead(BTN_1_PIN) == HIGH) {
            mode = 1; // Line Follower
            break;
        }
        if (digitalRead(BTN_2_PIN) == HIGH) {
            mode = 2; // Hardware Test
            break;
        }
        if (digitalRead(BTN_3_PIN) == HIGH) {
            mode = 3; // Kalibrasi
            break;
        }
        delay(50);
    }

    lcd.clear();
    // Jalankan mode yang dipilih
    if (mode == 1) {
        runLineFollower(lcd);
    } else if (mode == 2) {
        runHardwareTest(lcd);
    } else if (mode == 3) {
        calibrateSensors(lcd);
        // Setelah kalibrasi, kita bisa restart atau langsung lanjut
        ESP.restart();
    }
}

void loop() {
    // Execution will never reach here as both runHardwareTest 
    // and runLineFollower contain infinite loops.
}