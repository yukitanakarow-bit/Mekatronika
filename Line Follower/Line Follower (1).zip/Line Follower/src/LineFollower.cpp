#include "LineFollower.h"
#include "HardwareDefs.h"
#include <LiquidCrystal_I2C.h>
#include <Preferences.h>

Preferences preferences;
int sensorThresholds[8] = {2000, 2000, 2000, 2000, 2000, 2000, 2000, 2000};

// Forward declarations for functions defined in HardwareTest.cpp that we want
// to reuse
extern long getDistance();
extern int readMux(int channel);

// PID Constants (Need tuning)
// Kp dan Kd diperkecil drastis karena skala error 0-7000.
// Jika nilainya besar, robot hanya akan belok di tempat (spin) bukannya maju.
float Kp = 0.03;
float Ki = 0.0;
float Kd = 0.1;

int baseSpeed =
    150; // Speed dinaikkan agar motor kuat berputar (tidak cuma bergetar)
int maxSpeed = 255; // Kembalikan batas ke 255 agar leluasa bermanuver

int lastError = 0;
int integral = 0;
bool isLineLost = false;

// Set motor speeds (-maxSpeed to maxSpeed)
void setMotors(int speedLeft, int speedRight) {
  // Constrain speeds
  speedLeft = constrain(speedLeft, -maxSpeed, maxSpeed);
  speedRight = constrain(speedRight, -maxSpeed, maxSpeed);

  // Motor A (Left)
  if (speedLeft >= 0) {
    digitalWrite(MOTOR_A_IN1, LOW);
    digitalWrite(MOTOR_A_IN2, HIGH);
  } else {
    digitalWrite(MOTOR_A_IN1, HIGH);
    digitalWrite(MOTOR_A_IN2, LOW);
  }
  ledcWrite(PWM_CH_A, abs(speedLeft)); // Mengatur kecepatan sesungguhnya

  // Motor B (Right)
  if (speedRight >= 0) {
    digitalWrite(MOTOR_B_IN3, LOW);
    digitalWrite(MOTOR_B_IN4, HIGH);
  } else {
    digitalWrite(MOTOR_B_IN3, HIGH);
    digitalWrite(MOTOR_B_IN4, LOW);
  }
  ledcWrite(PWM_CH_B, abs(speedRight)); // Mengatur kecepatan sesungguhnya
}

// Calculate position based on 8 analog sensors (0 to 7000, center is 3500)
// Assuming dark line on light surface. Lower analog reading = dark line.
int getLinePosition() {
  long weightedSum = 0;
  long sum = 0;

  isLineLost = true;

  for (int i = 0; i < 8; i++) {
    int sensorValue = readMux(i);
    int threshold = sensorThresholds[i];

    // Let's assume sensorValue > threshold means white, < threshold means black
    // If we want white line on black surface, we invert this logic.
    // Assuming Black Line on White Surface:
    if (sensorValue > threshold) {
      isLineLost = false;
      // Map sensor index to weight (0, 1000, 2000... 7000)
      // Semakin hitam (sensorValue makin besar), bobot (value) harus makin
      // besar
      int value = sensorValue - threshold;
      weightedSum += (long)value * (i * 1000);
      sum += value;
    }
  }

  if (isLineLost) {
    return 3500; // Kembalikan nilai tengah sementara, logika goyang akan
                 // di-handle di loop utama
  }

  return (int)(weightedSum / sum);
}

void loadCalibration() {
  preferences.begin("calibration", true); // true = Read-only mode
  for (int i = 0; i < 8; i++) {
    String key = "thr" + String(i);
    sensorThresholds[i] = preferences.getInt(key.c_str(), 2000);
  }
  preferences.end();
}

void calibrateSensors(LiquidCrystal_I2C &lcd) {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Kalibrasi...");
  lcd.setCursor(0, 1);
  lcd.print("Geser di grs!");
  delay(2000);

  int minValues[8];
  int maxValues[8];

  for (int i = 0; i < 8; i++) {
    minValues[i] = 4095;
    maxValues[i] = 0;
  }

  unsigned long startTime = millis();
  // Kalibrasi selama 10 detik
  while (millis() - startTime < 10000) {
    for (int i = 0; i < 8; i++) {
      int val = readMux(i);
      if (val < minValues[i])
        minValues[i] = val;
      if (val > maxValues[i])
        maxValues[i] = val;
    }

    if ((millis() - startTime) % 1000 < 500) {
      lcd.setCursor(15, 1);
      lcd.print("*");
    } else {
      lcd.setCursor(15, 1);
      lcd.print(" ");
    }
    delay(10);
  }

  preferences.begin("calibration", false); // false = Read/Write mode
  for (int i = 0; i < 8; i++) {
    sensorThresholds[i] = (minValues[i] + maxValues[i]) / 2;
    String key = "thr" + String(i);
    preferences.putInt(key.c_str(), sensorThresholds[i]);
  }
  preferences.end();

  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Kalibrasi Selesai");
  delay(2000);
}

void runLineFollower(LiquidCrystal_I2C &lcd) {
  loadCalibration();

  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Line Follower");
  lcd.setCursor(0, 1);
  lcd.print("Running...");
  delay(1000);

  unsigned long lastLcdUpdate = 0;

  while (true) {
    // Update LCD secara periodik tanpa memblokir PID loop
    if (millis() - lastLcdUpdate > 200) {
      lastLcdUpdate = millis();

      char buf[17];
      sprintf(buf, "Spd: %-4d      ", baseSpeed);
      lcd.setCursor(0, 0);
      lcd.print(buf);

      lcd.setCursor(0, 1);
      for (int i = 0; i < 8; i++) {
        int val = readMux(i);
        if (val > sensorThresholds[i]) {
          lcd.print("1 ");
        } else {
          lcd.print("0 ");
        }
      }
    }

    // 1. Read Sensors & Get Position (Hanya berdasarkan sensor garis)
    int position = getLinePosition();

    if (isLineLost) {
      // Mode Pencarian: Goyang kanan-kiri pelan sambil maju (gerakan seperti
      // ular) Ganti arah goyangan tiap 400 milidetik
      int sweepState = (millis() / 400) % 2;
      int slowWheel = baseSpeed - 60; // Kurangi kecepatan roda bagian dalam
      if (slowWheel < 0)
        slowWheel = 0;

      if (sweepState == 0) {
        setMotors(baseSpeed, slowWheel); // Belok ke satu sisi
      } else {
        setMotors(slowWheel, baseSpeed); // Belok ke sisi lainnya
      }
      continue; // Skip PID dan langsung ke loop berikutnya
    }

    // 2. PID Calculation
    int error =
        position - 3500; // 3500 is the center point for 8 sensors (0-7000)
    integral += error;
    int derivative = error - lastError;

    int correction = (Kp * error) + (Ki * integral) + (Kd * derivative);
    lastError = error;

    // 3. Adjust Motor Speeds
    // Jika robot malah "menjauhi" garis saat belok, berarti kabel motor kiri
    // dan kanan Anda terbalik secara fisik. Saya menukar logika plus-minus di
    // bawah ini agar Anda tidak perlu membongkar kabel motor.
    int leftSpeed = baseSpeed - correction;
    int rightSpeed = baseSpeed + correction;

    setMotors(leftSpeed, rightSpeed);

    // Tombol Reset (B3) untuk kembali ke menu awal
    if (digitalRead(BTN_3_PIN)) {
      setMotors(0, 0);
      lcd.clear();
      lcd.print("Resetting...");
      delay(500);
      ESP.restart(); // Mereset ESP32
    }

    // Tombol B1 & B2 untuk mengatur baseSpeed (Speed + / Speed -)
    bool btn1 = digitalRead(BTN_1_PIN);
    bool btn2 = digitalRead(BTN_2_PIN);
    static bool lastBtn1 = false;
    static bool lastBtn2 = false;

    if (btn1 && !lastBtn1) {
      baseSpeed += 10;
      if (baseSpeed > 255)
        baseSpeed = 255;
      lastLcdUpdate = 0; // Memaksa update LCD
    }
    if (btn2 && !lastBtn2) {
      baseSpeed -= 10;
      if (baseSpeed < 0)
        baseSpeed = 0;
      lastLcdUpdate = 0; // Memaksa update LCD
    }
    lastBtn1 = btn1;
    lastBtn2 = btn2;

    // Small delay for stability
    delay(10);
  }
}
