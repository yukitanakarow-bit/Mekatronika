#include "HardwareTest.h"
#include "HardwareDefs.h"
#include <LiquidCrystal_I2C.h>

extern int sensorThresholds[8];
extern void loadCalibration();

void setupHardware() {
    // 1. Ultrasonic
    pinMode(US_TRIG_PIN, OUTPUT);
    pinMode(US_ECHO_PIN, INPUT);

    // 2. MUX Pins
    pinMode(MUX_S0_PIN, OUTPUT);
    pinMode(MUX_S1_PIN, OUTPUT);
    pinMode(MUX_S2_PIN, OUTPUT);
    pinMode(MUX_OUT_PIN, INPUT); // Analog input

    // 3. Motor Pins
    pinMode(MOTOR_A_IN1, OUTPUT);
    pinMode(MOTOR_A_IN2, OUTPUT);
    pinMode(MOTOR_B_IN3, OUTPUT);
    pinMode(MOTOR_B_IN4, OUTPUT);

    // Setup PWM for motors
    ledcSetup(PWM_CH_A, PWM_FREQ, PWM_RES);
    ledcAttachPin(MOTOR_A_EN, PWM_CH_A);
    
    ledcSetup(PWM_CH_B, PWM_FREQ, PWM_RES);
    ledcAttachPin(MOTOR_B_EN, PWM_CH_B);

    // Initial stop
    digitalWrite(MOTOR_A_IN1, LOW);
    digitalWrite(MOTOR_A_IN2, LOW);
    digitalWrite(MOTOR_B_IN3, LOW);
    digitalWrite(MOTOR_B_IN4, LOW);
    ledcWrite(PWM_CH_A, 0);
    ledcWrite(PWM_CH_B, 0);

    // 4. Pushbuttons
    // Using INPUT as external pull-down resistors are used.
    pinMode(BTN_1_PIN, INPUT);
    pinMode(BTN_2_PIN, INPUT);
    pinMode(BTN_3_PIN, INPUT);
}

// Helper to read distance from ultrasonic sensor
long getDistance() {
    digitalWrite(US_TRIG_PIN, LOW);
    delayMicroseconds(2);
    digitalWrite(US_TRIG_PIN, HIGH);
    delayMicroseconds(10);
    digitalWrite(US_TRIG_PIN, LOW);
    
    long duration = pulseIn(US_ECHO_PIN, HIGH, 30000); // 30ms timeout
    if (duration == 0) return -1; // Timeout
    return duration * 0.034 / 2; // Convert to cm
}

// Helper to read specific MUX channel (0-7)
int readMux(int channel) {
    // Membalikkan urutan dari 0-7 menjadi 7-0 karena fisik sensor terbalik
    channel = 7 - channel;
    
    digitalWrite(MUX_S0_PIN, bitRead(channel, 0));
    digitalWrite(MUX_S1_PIN, bitRead(channel, 1));
    digitalWrite(MUX_S2_PIN, bitRead(channel, 2));
    delayMicroseconds(5); // Settling time
    return analogRead(MUX_OUT_PIN);
}

// Simple hardware test routine
void runHardwareTest(LiquidCrystal_I2C &lcd) {
    loadCalibration(); // Memuat threshold sensor

    Serial.println("--- HARDWARE TEST MODE ---");
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("GUI Test Mode");
    lcd.setCursor(0, 1);
    lcd.print("Ready...");
    delay(1000);

    Serial.setTimeout(10); // Small timeout for non-blocking serial read
    unsigned long lastSend = 0;

    String incomingCommand = "";
    incomingCommand.reserve(50);

    int testSpeed = 0;
    bool lastBtn1 = false;
    bool lastBtn2 = false;
    unsigned long lastLcdUpdate = 0;

    while (true) {
        // Read Buttons for motor speed control
        bool btn1 = digitalRead(BTN_1_PIN);
        bool btn2 = digitalRead(BTN_2_PIN);

        if (btn1 && !lastBtn1) {
            testSpeed += 25;
            if (testSpeed > 255) testSpeed = 255;
        }
        if (btn2 && !lastBtn2) {
            testSpeed -= 25;
            if (testSpeed < -255) testSpeed = -255;
        }
        lastBtn1 = btn1;
        lastBtn2 = btn2;

        // Apply Motor Speeds
        if (testSpeed >= 0) {
            digitalWrite(MOTOR_A_IN1, LOW);
            digitalWrite(MOTOR_A_IN2, HIGH);
            ledcWrite(PWM_CH_A, testSpeed);
            digitalWrite(MOTOR_B_IN3, LOW);
            digitalWrite(MOTOR_B_IN4, HIGH);
            ledcWrite(PWM_CH_B, testSpeed);
        } else {
            digitalWrite(MOTOR_A_IN1, HIGH);
            digitalWrite(MOTOR_A_IN2, LOW);
            ledcWrite(PWM_CH_A, -testSpeed);
            digitalWrite(MOTOR_B_IN3, HIGH);
            digitalWrite(MOTOR_B_IN4, LOW);
            ledcWrite(PWM_CH_B, -testSpeed);
        }

        // Read incoming serial commands from GUI (Tetap bisa digunakan)
        while (Serial.available() > 0) {
            char c = Serial.read();
            if (c == '\n') {
                String cmd = incomingCommand;
                cmd.trim();
                incomingCommand = "";
                
                // Format: M:A:speed:B:speed (e.g. M:A:150:B:-150)
                if (cmd.startsWith("M:")) {
                    int firstColon = cmd.indexOf(':');
                    int secondColon = cmd.indexOf(':', firstColon + 1);
                    int thirdColon = cmd.indexOf(':', secondColon + 1);
                    int fourthColon = cmd.indexOf(':', thirdColon + 1);

                    if (firstColon != -1 && secondColon != -1 && thirdColon != -1 && fourthColon != -1) {
                        int speedA = cmd.substring(secondColon + 1, thirdColon).toInt();
                        int speedB = cmd.substring(fourthColon + 1).toInt();

                        // Motor A
                        if (speedA >= 0) {
                            digitalWrite(MOTOR_A_IN1, LOW);
                            digitalWrite(MOTOR_A_IN2, HIGH);
                            ledcWrite(PWM_CH_A, speedA);
                        } else {
                            digitalWrite(MOTOR_A_IN1, HIGH);
                            digitalWrite(MOTOR_A_IN2, LOW);
                            ledcWrite(PWM_CH_A, -speedA);
                        }

                        // Motor B
                        if (speedB >= 0) {
                            digitalWrite(MOTOR_B_IN3, LOW);
                            digitalWrite(MOTOR_B_IN4, HIGH);
                            ledcWrite(PWM_CH_B, speedB);
                        } else {
                            digitalWrite(MOTOR_B_IN3, HIGH);
                            digitalWrite(MOTOR_B_IN4, LOW);
                            ledcWrite(PWM_CH_B, -speedB);
                        }
                    }
                }
            } else {
                incomingCommand += c;
            }
        }

        // Tombol Reset (B3) untuk kembali ke menu awal
        if (digitalRead(BTN_3_PIN)) {
            digitalWrite(MOTOR_A_IN1, LOW);
            digitalWrite(MOTOR_A_IN2, LOW);
            digitalWrite(MOTOR_B_IN3, LOW);
            digitalWrite(MOTOR_B_IN4, LOW);
            ledcWrite(PWM_CH_A, 0);
            ledcWrite(PWM_CH_B, 0);
            lcd.clear();
            lcd.print("Resetting...");
            delay(500);
            ESP.restart(); // Mereset ESP32
        }

        // Send telemetry data & Update LCD every 100ms
        if (millis() - lastSend >= 100) {
            lastSend = millis();
            
            int b1 = digitalRead(BTN_1_PIN);
            int b2 = digitalRead(BTN_2_PIN);
            int b3 = digitalRead(BTN_3_PIN);
            long dist = getDistance();
            
            int m[8];
            for (int i=0; i<8; i++) m[i] = readMux(i);

            // Print JSON to serial
            Serial.printf("{\"us\":%ld,\"btn\":[%d,%d,%d],\"mux\":[%d,%d,%d,%d,%d,%d,%d,%d]}\n",
                dist, b1, b2, b3, m[0], m[1], m[2], m[3], m[4], m[5], m[6], m[7]);
        }

        if (millis() - lastLcdUpdate > 200) {
            lastLcdUpdate = millis();
            
            if (testSpeed == 0) {
                // Tampilkan raw value asli 0-4095. 4 sensor x 4 digit = pas 16 karakter tanpa spasi
                lcd.setCursor(0, 0);
                lcd.printf("%4d%4d%4d%4d", readMux(0), readMux(1), readMux(2), readMux(3));
                lcd.setCursor(0, 1);
                lcd.printf("%4d%4d%4d%4d", readMux(4), readMux(5), readMux(6), readMux(7));
            } else {
                // Saat motor dites, tampilkan Kecepatan & Digital 0/1 untuk memantau track
                char buf[17];
                sprintf(buf, "Spd: %-4d      ", testSpeed);
                lcd.setCursor(0, 0);
                lcd.print(buf);
                
                lcd.setCursor(0, 1);
                for(int i=0; i<8; i++) {
                    int val = readMux(i);
                    // Hitam = 1, Putih = 0
                    if (val > sensorThresholds[i]) {
                        lcd.print("1 ");
                    } else {
                        lcd.print("0 ");
                    }
                }
            }
        }
    }
}
