#ifndef HARDWARE_TEST_H
#define HARDWARE_TEST_H

#include <Arduino.h>

// Forward declaration of LiquidCrystal_I2C so we don't have to include it here
class LiquidCrystal_I2C;

void setupHardware();
void runHardwareTest(LiquidCrystal_I2C &lcd);

#endif // HARDWARE_TEST_H
