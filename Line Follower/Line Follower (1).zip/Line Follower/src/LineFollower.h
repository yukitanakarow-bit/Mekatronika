#ifndef LINE_FOLLOWER_H
#define LINE_FOLLOWER_H

#include <Arduino.h>

class LiquidCrystal_I2C;

void runLineFollower(LiquidCrystal_I2C &lcd);
void calibrateSensors(LiquidCrystal_I2C &lcd);

#endif // LINE_FOLLOWER_H
